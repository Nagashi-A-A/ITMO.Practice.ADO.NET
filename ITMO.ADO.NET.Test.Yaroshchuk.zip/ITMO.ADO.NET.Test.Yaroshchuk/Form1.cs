﻿using ITMO.ADO.NET.Test.Yaroshchuk.NorthwindDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Common.EntitySql;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ITMO.ADO.NET.Test.Yaroshchuk
{
    public partial class Form1 : Form
    {
        private NorthwindEntities NWContext;
        private string access = "123454321";
        CustomersTableAdapter newCustAdapter = new CustomersTableAdapter();
        ProductsTableAdapter newProdAdapter = new ProductsTableAdapter();
        OrdersTableAdapter newOrdAdapter = new OrdersTableAdapter();


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            NWContext = new NorthwindEntities();
        }

        private void UploadButton_Click(object sender, EventArgs e)
        {
            string custID = tbCustID.Text;
            string empID = textBoxID.Text + textBoxPass.Text;
            try
            {
                //Запросы клиентов:
                // Клиенты могут видеть только информацию, запрашиваемую с использованием их CustomerID, а так же информацию о товарах при помощи LINQ запросов.
                if (this.clientRadioBttn.Checked == true)
                {
                    if(this.customerRadioBttn.Checked == true)
                    {
                        var custDetails =
                                          from c in NWContext.Customers
                                          where c.CustomerID == custID
                                          select c;
                        dataGridView1.DataSource = custDetails.ToList();
                    }
                    else if (this.productRadioBttn.Checked == true)
                    {
                        var custProducts =
                                            from p in NWContext.Products
                                            select p;
                        dataGridView1.DataSource = custProducts.ToList();
                    }

                    else if (this.ordeRadioBttn.Checked == true)
                    {
                        var custOrders =
                                          from o in NWContext.Orders
                                          where o.CustomerID == custID
                                          select o;
                        dataGridView1.DataSource = custOrders.ToList();
                    }
                }
                //Запросы сотрудников:
                // Сотрудники могут просматривать информацию о продажах указав желаемый период времени при помощи LINQ запроса, а так же редактировать и создавать новые заказы, добавлять товары и клиентов при помощи DataSet.
                else if (this.empRadioBttn.Checked == true && empID == access)
                {
                    if (this.customerRadioBttn.Checked == true)
                    {
                        BindingSource customersBindingSource = new BindingSource(northwindDataSet, "Customers");
                        dataGridView1.DataSource = customersBindingSource;
                        bindingNavigator1.BindingSource = customersBindingSource;
                        newCustAdapter.Fill(northwindDataSet.Customers);
                    }
                    else if (this.productRadioBttn.Checked == true)
                    {
                        BindingSource productsBindingSource = new BindingSource(northwindDataSet, "Products");
                        dataGridView1.DataSource = productsBindingSource;
                        bindingNavigator1.BindingSource = productsBindingSource;
                        newProdAdapter.Fill(northwindDataSet.Products);
                    }

                    else if (this.ordeRadioBttn.Checked == true)
                    {
                        BindingSource ordersBindingSource = new BindingSource(northwindDataSet, "Orders");
                        dataGridView1.DataSource = ordersBindingSource;
                        bindingNavigator1.BindingSource = ordersBindingSource;
                        newOrdAdapter.Fill(northwindDataSet.Orders);
                    }

                    else if (this.salesRadioBttn.Checked == true)
                    {
                        DateTime periodFrom = DateTime.Parse(fromTextBox.Text);
                        DateTime periodTo = DateTime.Parse(toTextBox.Text);
                        var sales =
                                          from s in NWContext.Sales_by_Year(periodFrom, periodTo)
                                          select s;
                        dataGridView1.DataSource = sales.ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: "+ ex.ToString());            
            }
        }
        //После добавления новых данных или обновления уже существующих, сотрудник загружает их в источник данных при помощи метода Update().
        private void UpdateButton_Click(object sender, EventArgs e)
        {
            string empID = textBoxID.Text + textBoxPass.Text;
            try
            {
                if (this.empRadioBttn.Checked == true && empID == access)
                {
                    if (this.customerRadioBttn.Checked == true)
                    {
                        newCustAdapter.Update(northwindDataSet.Customers);
                    }
                    else if (this.productRadioBttn.Checked == true)
                    {
                        newProdAdapter.Update(northwindDataSet.Products);
                    }

                    else if (this.ordeRadioBttn.Checked == true)
                    {
                        newOrdAdapter.Update(northwindDataSet.Orders);
                    }
                }
            }
            catch (Exception excptn)
            {
                MessageBox.Show("Error: " + excptn.ToString());
            }
        }

        // Так же дадим сотрудникам возможность сохранять XML файлы для чтения.

        private void DownloadButton_Click(object sender, EventArgs e)
        {
            string empID = textBoxID.Text + textBoxPass.Text;
            try
            {
                if (this.empRadioBttn.Checked == true && empID == access)
                {
                    if (this.customerRadioBttn.Checked == true)
                    {
                        northwindDataSet.Customers.WriteXml("NWxmlCustomers.xml");
                        MessageBox.Show("Customers Table was downloaded to XML.");
                        northwindDataSet.WriteXmlSchema("Northwind.xsd");
                    }
                    else if (this.productRadioBttn.Checked == true)
                    {
                        northwindDataSet.Products.WriteXml("NWxmlProducts.xml");
                        MessageBox.Show("Products Table was downloaded to XML.");
                        northwindDataSet.WriteXmlSchema("Northwind.xsd");
                    }

                    else if (this.ordeRadioBttn.Checked == true)
                    {
                        northwindDataSet.Orders.WriteXml("NWxmlOrders.xml");
                        MessageBox.Show("Orders Table was downloaded to XML.");
                        northwindDataSet.WriteXmlSchema("Northwind.xsd");
                    }
                }
            }
            catch (Exception excptn)
            {
                MessageBox.Show("Error: " + excptn.ToString());
            }
        }


        //Добавим сотрудникам возможность просмотра загруженных XML файлов.
        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string empID = textBoxID.Text + textBoxPass.Text;
            try
            {
                if (this.empRadioBttn.Checked == true && empID == access)
                {
                    if (this.customerRadioBttn.Checked == true)
                    {
                        var fileContent = string.Empty;
                        var filePath = string.Empty;
                        DataSet nw = new DataSet();

                        using (OpenFileDialog openFileDialog = new OpenFileDialog())
                        {
                            openFileDialog.InitialDirectory = "c:\\";
                            openFileDialog.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
                            openFileDialog.FilterIndex = 2;
                            openFileDialog.RestoreDirectory = true;

                            if (openFileDialog.ShowDialog() == DialogResult.OK)
                            {
                                filePath = openFileDialog.FileName;
                                string myPath = filePath;
                                nw.ReadXmlSchema("Northwind.xsd");
                                nw.ReadXml(myPath);
                                dataGridView1.DataSource = nw.Tables["Customers"];
                            }
                        }
                    }
                    else if (this.productRadioBttn.Checked == true)
                    {
                        var fileContent = string.Empty;
                        var filePath = string.Empty;
                        DataSet nw = new DataSet();

                        using (OpenFileDialog openFileDialog = new OpenFileDialog())
                        {
                            openFileDialog.InitialDirectory = "c:\\";
                            openFileDialog.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
                            openFileDialog.FilterIndex = 2;
                            openFileDialog.RestoreDirectory = true;

                            if (openFileDialog.ShowDialog() == DialogResult.OK)
                            {
                                //Get the path of specified file
                                filePath = openFileDialog.FileName;
                                string myPath = filePath;
                                nw.ReadXmlSchema("Northwind.xsd");
                                nw.ReadXml(myPath);
                                dataGridView1.DataSource = nw.Tables["Products"];
                            }
                        }
                    }

                    else if (this.ordeRadioBttn.Checked == true)
                    {
                        var fileContent = string.Empty;
                        var filePath = string.Empty;
                        DataSet nw = new DataSet();

                        using (OpenFileDialog openFileDialog = new OpenFileDialog())
                        {
                            openFileDialog.InitialDirectory = "c:\\";
                            openFileDialog.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
                            openFileDialog.FilterIndex = 2;
                            openFileDialog.RestoreDirectory = true;

                            if (openFileDialog.ShowDialog() == DialogResult.OK)
                            {
                                //Get the path of specified file
                                filePath = openFileDialog.FileName;
                                string myPath = filePath;
                                nw.ReadXmlSchema("Northwind.xsd");
                                nw.ReadXml(myPath);
                                dataGridView1.DataSource = nw.Tables["Orders"];
                            }
                        }
                    }
                }
            }
            catch (Exception excptn)
            {
                MessageBox.Show("Error: " + excptn.ToString());
            }

            if (this.customerRadioBttn.Checked == true)
            {
                var fileContent = string.Empty;
                var filePath = string.Empty;
                DataSet nw = new DataSet();

                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.InitialDirectory = "c:\\";
                    openFileDialog.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
                    openFileDialog.FilterIndex = 2;
                    openFileDialog.RestoreDirectory = true;

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        //Get the path of specified file
                        filePath = openFileDialog.FileName;
                        string myPath = filePath;
                        nw.ReadXmlSchema("Northwind.xsd");
                        nw.ReadXml(myPath);
                        dataGridView1.DataSource = nw.Tables["Customers"];
                    }
                }
            }
        }
    }
}
